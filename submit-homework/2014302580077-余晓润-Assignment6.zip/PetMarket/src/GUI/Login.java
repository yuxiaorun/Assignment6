package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DAO.DBC;
import DAO.UserDAO;
import mass.User;

import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;

public class Login extends JFrame {

	private JPanel contentPane;
	private JPanel register;
	private JTextField UserNameTF;
	private JPasswordField passwordF;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 */
	public Login() throws ClassNotFoundException 
		{
		setTitle("\u767B\u5F55");DBC dbc=new DBC();
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			setBounds(100, 100, 450, 300);
			register = new JPanel();
			register.setBorder(new EmptyBorder(5, 5, 5, 5));
			register.setLayout(null);
			
			contentPane = new JPanel();
			contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
			contentPane.setLayout(null);
			setContentPane(contentPane);
			
			JLabel lblNewLabel = new JLabel("\u4E60\u4E60\u86E4\u86E4\u5BA0\u7269\u5E02\u573A");
			lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
			lblNewLabel.setBounds(91, 25, 247, 40);
			contentPane.add(lblNewLabel);
			
			UserNameTF = new JTextField();
			UserNameTF.setBounds(68, 102, 167, 34);
			contentPane.add(UserNameTF);
			UserNameTF.setColumns(10);
			
			JLabel label = new JLabel("\u8D26\u53F7");
			label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			label.setBounds(10, 105, 54, 27);
			contentPane.add(label);
			
			JLabel label_1 = new JLabel("\u5BC6\u7801");
			label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
			label_1.setBounds(10, 170, 54, 27);
			contentPane.add(label_1);
			JLabel lblNewLabel_1 = new JLabel("\u8BF7\u767B\u5F55\u6216\u6CE8\u518C\u65B0\u7528\u6237");
			lblNewLabel_1.setBounds(78, 221, 143, 20);
			contentPane.add(lblNewLabel_1);
			
			JButton btnNewButton = new JButton("\u6CE8\u518C");
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					register register;
					try {
						register = new register();
						register.setVisible(true);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			});
			btnNewButton.setBounds(296, 98, 93, 40);
			contentPane.add(btnNewButton);
			
			JButton button = new JButton("\u767B\u5F55");
			button.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String username=UserNameTF.getText();
					@SuppressWarnings("deprecation")
					String password=passwordF.getText();
					try {
						UserDAO ud=new UserDAO(dbc.getConnection());
						if(dbc.getConnection()==null){
							lblNewLabel_1.setText("����ʧ�ܣ�");
						}
						else{
						if(ud.Login(username, password)){
							User user=ud.getUser(username, password);
								market market=new market(user);
								market.setVisible(true);
								setVisible(false);
						}
						else{
							lblNewLabel_1.setText("�û������������");
						}}
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
				}
			});
			button.setBounds(296, 162, 93, 40);
			contentPane.add(button);
			
			
			passwordF = new JPasswordField();
			passwordF.setBounds(68, 161, 167, 34);
			contentPane.add(passwordF);
		}
}
