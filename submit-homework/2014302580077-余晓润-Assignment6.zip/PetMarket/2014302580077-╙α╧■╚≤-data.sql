-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: my_schema
-- ------------------------------------------------------
-- Server version	5.6.27-log


INSERT INTO `2014302580077_pet` VALUES (1,'dog','bone','water','ground','play',10),(2,'cat','fish','milk','roof','hug',10),(3,'turtle','fish,shrimp','sea water','sea water','bask',5),(4,'parrot','nuts,seeds','water','tree','fly',20),(5,'hamster','Sunflower seed','water','corner','eat',5),(6,'squirrel','pine cone','water','tree hole,underground','play',15),(7,'rabbit','carrot','water','grassland,underground','eat',10),(8,'snake','mouse','water','hole','bask',30),(9,'lizard','bug','water','tree','bask',30),(10,'fish','aquatic plant','water','water','swim',5),(11,'myna','earthworm','water','tree','fly',30),(12,'canary','millet','water','tree','sing',50);
INSERT INTO `2014302580077_user` VALUES (1,'yuxiaorun','134679','752304557@163.com',920),(5,'yu','ss','ssss@qq.com',1000);
INSERT INTO `2014302580077_cart` VALUES (1,1,10,1,'done'),(1,2,10,2,'done'),(1,4,20,3,'done'),(1,5,5,4,'done'),(1,2,10,5,'done'),(1,5,5,6,'done'),(1,6,15,7,'done'),(1,2,10,8,'done'),(1,1,10,9,'done'),(1,2,10,10,'done'),(1,4,20,11,'done'),(1,4,20,12,'done'),(1,5,5,13,'done'),(1,4,20,14,'wait');
-- Dump completed on 2015-12-03 20:42:31
