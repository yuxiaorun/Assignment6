package DAO;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import mass.Pet;

import java.sql.Connection;
import java.sql.ResultSet;
public class PetDAO {
	 private Connection conn;
	 private Statement st;
	 public PetDAO(Connection conn) throws SQLException{
		 this.conn=conn;
		 st=conn.createStatement(); 
	 }
	 public List<Pet> getAll() throws SQLException{
		ArrayList<Pet> pets=new ArrayList();
		 ResultSet resultset=st.executeQuery("select id,name,eat,drink,live,hobby,price from 2014302580077_pet order by ID");
		 while(resultset.next()){
			 Pet pet=new Pet(resultset.getInt(1),resultset.getString(2),resultset.getString(3),resultset.getString(4),resultset.getString(5),resultset.getString(6),resultset.getInt(7));
			 pets.add(pet);
		 }
		 return pets;
	 }
	 public Pet getByName(String name) throws SQLException{
		 ResultSet resultset=st.executeQuery("select id,name,eat,drink,live,hobby,price from 2014302580077_pet where name='"+name+"'");
		 resultset.next();
		 Pet pet=new Pet(resultset.getInt(1),resultset.getString(2),resultset.getString(3),resultset.getString(4),resultset.getString(5),resultset.getString(6),resultset.getInt(7));
		 return pet;
	 }
}
