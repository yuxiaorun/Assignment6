package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Spring;
import javax.swing.border.EmptyBorder;

import DAO.DBC;
import DAO.PetDAO;
import DAO.cartDAO;
import mass.Pet;
import mass.User;

import java.awt.CardLayout;
import javax.swing.JComboBox;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.ItemSelectable;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class market extends JFrame {
 private ArrayList<Pet> pets;
	private JPanel contentPane;
	private DBC dbc;
	private PetDAO pd;
    private User user;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public market(User user) throws ClassNotFoundException, SQLException {
		setTitle("\u5BA0\u7269\u5E02\u573A");
		this.user=user;
		dbc=new DBC();
		pd=new PetDAO(dbc.getConnection());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 550, 460);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JComboBox selectBox = new JComboBox();
		selectBox.setBounds(84, 32, 93, 21);
		initiate(selectBox);
		contentPane.add(selectBox);
		
		JButton cartButton = new JButton("\u6211\u7684\u8D2D\u7269\u8F66");
		cartButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					cart cart=new cart(user);
					cart.setVisible(true);
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		cartButton.setBounds(382, 367, 115, 45);
		contentPane.add(cartButton);
		
		JLabel label = new JLabel("\u9009\u62E9\u5BA0\u7269\uFF1A");
		label.setBounds(10, 35, 66, 15);
		contentPane.add(label);
		JLabel cartInf = new JLabel("");
		cartInf.setBounds(45, 367, 115, 21);
		contentPane.add(cartInf);
		JButton BuyBotton = new JButton("\u8D2D\u4E70\uFF01");
		BuyBotton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					cartDAO cd=new cartDAO(dbc.getConnection());
					Pet pet=pd.getByName((String)selectBox.getSelectedItem());
					cd.add(pet, user);
					cartInf.setText("�Ѽ��빺�ﳵ��");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		});
		BuyBotton.setBounds(393, 322, 93, 28);
		contentPane.add(BuyBotton);
		
		JLabel namel = new JLabel("\u540D\u5B57\uFF1A");
		namel.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		namel.setBounds(351, 84, 57, 28);
		contentPane.add(namel);
		
		JLabel eatl = new JLabel("\u5403\u5565\uFF1A");
		eatl.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		eatl.setBounds(351, 122, 57, 21);
		contentPane.add(eatl);
		
		JLabel label_1 = new JLabel("\u559D\u5565\uFF1A");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label_1.setBounds(351, 153, 57, 21);
		contentPane.add(label_1);
		
		JLabel label_2 = new JLabel("\u4F4F\u54EA\uFF1A");
		label_2.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label_2.setBounds(351, 184, 57, 21);
		contentPane.add(label_2);
		
		JLabel label_3 = new JLabel("\u7231\u597D\uFF1A");
		label_3.setFont(new Font("΢���ź�", Font.PLAIN, 14));
		label_3.setBounds(351, 215, 57, 21);
		contentPane.add(label_3);
		
		JLabel named = new JLabel("dog");
		named.setBounds(418, 89, 93, 20);
		contentPane.add(named);
		
		JLabel eatd = new JLabel("bone");
		eatd.setBounds(418, 123, 93, 20);
		contentPane.add(eatd);
		
		JLabel drinkd = new JLabel("drink");
		drinkd.setBounds(418, 154, 93, 20);
		contentPane.add(drinkd);
		
		JLabel lived = new JLabel("ground");
		lived.setBounds(418, 185, 93, 20);
		contentPane.add(lived);
		
		JLabel hobbyd = new JLabel("play");
		hobbyd.setBounds(418, 216, 93, 20);
		contentPane.add(hobbyd);
		
		JLabel pricel = new JLabel("\u4EF7\u683C\uFF1A");
		pricel.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		pricel.setBounds(31, 290, 66, 43);
		contentPane.add(pricel);
		
		JLabel priced = new JLabel("");
		priced.setFont(new Font("΢���ź�", Font.PLAIN, 20));
		priced.setBounds(111, 290, 66, 43);
		contentPane.add(priced); 
		JLabel ImageLabel = new JLabel("");
		ImageLabel.setBounds(33, 84, 278, 176);
		ImageLabel.setIcon(new ImageIcon("image\\dog.jpg"));
		contentPane.add(ImageLabel);
		
		JLabel lblNewLabel = new JLabel("��ӭ��"+user.getName());
		lblNewLabel.setBounds(22, 7, 120, 15);
		contentPane.add(lblNewLabel);
	
		  ItemListener itemListener = new ItemListener() {
		      public void itemStateChanged(ItemEvent itemEvent) {
		      String name=(String)itemEvent.getItem();
		      try {
				Pet pet=pd.getByName(name);
				named.setText(pet.getName());
				eatd.setText(pet.getEat());
				drinkd.setText(pet.getDrink());
				lived.setText(pet.getLive());
				hobbyd.setText(pet.getHobby());
				priced.setText(String.valueOf(pet.getPrice()));
				ImageLabel.setIcon(new ImageIcon("image\\"+pet.getName()+".jpg"));
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		      
		      }
		    };
		    selectBox.addItemListener(itemListener);
	}
	private void initiate(JComboBox selectBox) throws SQLException{
		pets=(ArrayList<Pet>) pd.getAll();
		for(Pet pet:pets){
			selectBox.addItem(pet.getName());
		}
	}
}
