package DAO;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import mass.Order;
import mass.Pet;
import mass.User;
public class cartDAO {
	private Connection conn;
	private PreparedStatement st;
	public cartDAO(Connection conn) throws SQLException{
		this.conn=conn;
	}
	public void add(Pet pet,User user) throws SQLException{
		String sql="Insert into 2014302580077_cart(userID,petID,price) values(?,?,?)";
		st=conn.prepareStatement(sql);
		st.setInt(1,user.getID());
		st.setInt(2,pet.getID());
		st.setInt(3, pet.getPrice());
		st.executeUpdate();
	}
	public List<Order> getOrderInf(User user) throws SQLException{
		ArrayList<Order> orders=new ArrayList(); 
		ResultSet resultset=conn.createStatement().executeQuery("select userID,petID,price,orderID from 2014302580077_cart where state='wait' and userID="+user.getID());
		 while(resultset.next()){
			Order order=new Order(resultset.getInt(4), resultset.getInt(2),resultset.getInt(1),resultset.getInt(3));
			 orders.add(order);
		 }
		 return orders;
	}
   public void remove(User user) throws SQLException{
	   conn.createStatement().executeUpdate("update 2014302580077_cart set state='cancel' where userID="+user.getID());
   }
   public void buy(User user) throws SQLException{
	   conn.createStatement().executeUpdate("update 2014302580077_cart set state='done' where userID="+user.getID());
   }
}
