package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBC {
private Connection conn;
public DBC() throws ClassNotFoundException{
	 Class.forName("com.mysql.jdbc.Driver");
		try {
			conn=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/my_schema?user=root&password=123456");
		} catch (SQLException e) {
			System.out.println("��������ʧ��");
			e.printStackTrace();
		}
}
public Connection getConnection(){
	if(conn==null)System.out.println("����δ��ʼ��");
	return conn;
}
}

