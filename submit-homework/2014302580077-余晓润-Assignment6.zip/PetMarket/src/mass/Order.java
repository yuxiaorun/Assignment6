package mass;

public class Order {
private int id;
private int petid;
private int userid;
private int price;
public Order(int id,int petid,int userid,int price){
	this.id=id;
	this.petid=petid;
	this.userid=userid;
	this.price=price;
}
public int getid(){
	return id;
}
public int getUserid(){
	return userid;
}
public int getPrice(){
	return price;
}
public int getPetid(){
	return petid;
}

}
