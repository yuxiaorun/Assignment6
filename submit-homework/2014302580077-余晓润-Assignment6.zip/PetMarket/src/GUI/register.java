package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DAO.DBC;
import DAO.UserDAO;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.UnsupportedEncodingException;
import java.sql.SQLException;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;

public class register extends JFrame {

	private JPanel contentPane;
	private JTextField textField1;
	private JTextField textField2;
	private JTextField textField3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					register frame = new register();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 */
	public register() throws ClassNotFoundException {
		DBC dbc=new DBC();
		setBounds(100, 100, 352, 433);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("\u6B22\u8FCE\uFF01");
		lblNewLabel.setFont(new Font("΢���ź�", Font.PLAIN, 30));
		lblNewLabel.setBounds(37, 10, 245, 60);
		contentPane.add(lblNewLabel);
		
		textField1 = new JTextField();
		textField1.setBounds(104, 110, 155, 27);
		contentPane.add(textField1);
		textField1.setColumns(10);
		
		textField2 = new JTextField();
		textField2.setColumns(10);
		textField2.setBounds(104, 169, 155, 27);
		contentPane.add(textField2);
		
		textField3 = new JTextField();
		textField3.setColumns(10);
		textField3.setBounds(104, 222, 155, 27);
		contentPane.add(textField3);
		
		JLabel lblNewLabel_1 = new JLabel("\u7528\u6237\u540D");
		lblNewLabel_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		lblNewLabel_1.setBounds(21, 113, 60, 21);
		contentPane.add(lblNewLabel_1);
		
		JLabel label = new JLabel("\u5BC6\u7801");
		label.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label.setBounds(21, 171, 60, 21);
		contentPane.add(label);
		
		JLabel label_1 = new JLabel("\u90AE\u7BB1");
		label_1.setFont(new Font("΢���ź�", Font.PLAIN, 15));
		label_1.setBounds(21, 224, 60, 21);
		contentPane.add(label_1);
		JLabel InfLabel = new JLabel("");
		InfLabel.setBounds(104, 259, 155, 21);
		contentPane.add(InfLabel);
		JButton registerButton = new JButton("\u6CE8\u518C");
		registerButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String userName=textField1.getText();
				String password=textField2.getText();
				String email=textField3.getText();
	    
				try {
					if(userName.isEmpty()||password.isEmpty()||!Pattern.matches("\\w+@\\w+\\.\\w+", email)){
					InfLabel.setText("������������Ч��Ϣ ");
				}
				else{
					UserDAO ud=new UserDAO(dbc.getConnection());
					if(dbc.getConnection()==null){
							InfLabel.setText("����ʧ�ܣ�");
						}
					if(ud.create(userName, password, email)){
						InfLabel.setText("ע��ɹ� ");
					}
					else
						InfLabel.setText("�����û����ظ�");}
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		registerButton.setBounds(114, 291, 133, 44);
		contentPane.add(registerButton);
		
		
	}
}
