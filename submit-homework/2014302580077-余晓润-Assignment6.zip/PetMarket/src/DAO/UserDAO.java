package DAO;

import java.sql.SQLException;
import java.sql.Statement;

import java.sql.Connection;
import java.sql.PreparedStatement;

import mass.Order;
import mass.User;
import java.sql.ResultSet;

public class UserDAO {
	 private Connection conn;
	 private PreparedStatement stat;
	 public UserDAO(Connection conn) throws SQLException{
		 this.conn=conn;
	 }
	 public boolean create(String username,String password,String email) throws SQLException{
		 stat=conn.prepareStatement("select id,username,password,email from 2014302580077_user where username=?");
		 stat.setString(1, username);
		 ResultSet resultset=stat.executeQuery();
		 System.out.println(resultset.getFetchSize());
		 if(resultset.next()){
			System.out.println("already exist");
			 return false;
		 }
		 stat.executeUpdate("Insert into 2014302580077_user(username,password,email) values('"+username+"','"+password+"','"+email+"')");
		 return true;
}
     public boolean Login(String username,String password) throws SQLException{
    	 stat=conn.prepareStatement("select id,username,password,email from 2014302580077_user where username=? and password=?");
		 stat.setString(1, username);
		 stat.setString(2, password);
    	 ResultSet resultset=stat.executeQuery();
    	if(!resultset.next())
    	{	
    		return false;
    		}
    	return true;
     }
     public User getUser(String username,String password) throws SQLException{
    	 User user=new User();
    	 stat=conn.prepareStatement("select id,username,password,email,money from 2014302580077_user where username=? and password=?");
		 stat.setString(1, username);
		 stat.setString(2, password);
    	 ResultSet resultset=stat.executeQuery();
    	 resultset.next();
    	 user.setID(resultset.getInt(1));
 		user.setName(resultset.getString(2));
 		user.setPassword(resultset.getString(3));
 		user.setEmail(resultset.getString(4));
 		user.setMoney(resultset.getInt(5));
 		return user;
     }
     public User getById(int id) throws SQLException{
    	 ResultSet resultset=stat.executeQuery("select id,username,password,email,money from 2014302580077_pet where id="+id);
    	 resultset.next();
    	 User user=new User(resultset.getInt(1),resultset.getString(2),resultset.getString(3),resultset.getString(4),resultset.getInt(5));
    	 return user;
     }
     public void updateMoney(User user) throws SQLException{
    	 conn.createStatement().executeUpdate("update 2014302580077_user set money="+user.getMoney()+" where id="+user.getID());
     }
     
     
     
}