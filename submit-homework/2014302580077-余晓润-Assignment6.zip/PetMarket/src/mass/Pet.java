package mass;

public class Pet {
private int id;
private String name;
private String eat;
private String drink;
private String live;
private String hobby;
private int price;
public Pet(int id,String name,String eat,String drink,String live,String hobby,int price){
	this.id=id;
	this.name=name;
	this.eat=eat;
	this.drink=drink;
	this.live=live;
	this.hobby=hobby;
	this.price=price;
}
public int getID(){
	return id;
}
public String getName(){
	return name;
}
public int getPrice(){
	return price;
}
public String getEat(){
	return eat;
}
public String getDrink(){
	return drink;
}
public String getLive(){
	return live;
}
public String getHobby(){
	return hobby;
}
}
