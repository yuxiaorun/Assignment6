package mass;

public class User {
	private int id;
	private int money;
private String username;
private String password;
private String email;
public User(){this.money=1000;};
public User(int id,String name,String password,String email,int money){
	this.id=id;
	this.username=name;
	this.password=password;
	this.email=email;
	this.money=money;
}
public void setID(int id){
	this.id=id;
}
public int getID(){
	return id;
}
public void setName(String name){
	this.username=name;
}
public void setPassword(String password){
	this.password=password;
}
public void setEmail(String email){
	this.email=email;
}
public String getName(){
	return username;
}
public String getPassword(){
	return password;
}
public String getEmail(){
	return email;
}
public int getMoney(){
	return money;
}
public void setMoney(int money){
	this.money=money;
}
public void costMoney(Order order){
	money-=order.getPrice();
}
}
