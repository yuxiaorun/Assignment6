package GUI;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import DAO.DBC;
import DAO.UserDAO;
import DAO.cartDAO;
import mass.Order;
import mass.User;

import javax.swing.JButton;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class cart extends JFrame {
  private DBC dbc;
	private JPanel contentPane;
    private cartDAO cd;
    private UserDAO ud;
    private User user;
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 * @throws ClassNotFoundException 
	 * @throws SQLException 
	 */
	public cart(User user) throws ClassNotFoundException, SQLException {
		this.user=user;
		dbc=new DBC();
		ud=new UserDAO(dbc.getConnection());
		setTitle("\u8D2D\u7269\u8F66");
		setBounds(100, 100, 406, 380);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(null);
		setContentPane(contentPane);
		
		
		JTextArea OrderInf = new JTextArea();
		OrderInf.setEditable(false);
		OrderInf.setText("userID       petID       price        orderID");
	 cd=new cartDAO(dbc.getConnection());
		updateInf(OrderInf);
		OrderInf.setBounds(92, 10, 212, 220);
		contentPane.add(OrderInf);

		JButton clearButton = new JButton("\u6E05\u7A7A");
		clearButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OrderInf.setText("userID       petID       price        orderID");
				try {
					cd.remove(user);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		clearButton.setBounds(42, 266, 103, 45);
		contentPane.add(clearButton);
		
		JLabel lblNewLabel = new JLabel("�������:"+user.getMoney());
		lblNewLabel.setBounds(42, 240, 157, 15);
		contentPane.add(lblNewLabel);
		
		JButton Buybutton = new JButton("\u7ED3\u7B97");
		Buybutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				OrderInf.setText("userID       petID       price        orderID");
			
				try {
					ArrayList<Order> orders=(ArrayList<Order>) cd.getOrderInf(user);
					for(Order i:orders){
						user.costMoney(i);
					}
				 lblNewLabel.setText("�������:"+user.getMoney());
					ud.updateMoney(user);
					cd.buy(user);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		Buybutton.setBounds(228, 266, 103, 45);
		contentPane.add(Buybutton);
	}
	private void updateInf(JTextArea OrderInf) throws SQLException{
		ArrayList<Order> orders=(ArrayList<Order>) cd.getOrderInf(user);
		for(Order i:orders){
			OrderInf.append("\n    "+i.getUserid()+"                "+i.getPetid()+"            "+i.getPrice()+"             "+i.getid());
		}
	}
}
